import React from "react";
import { ScrollView, View } from "react-native";
import Header from "../components/Header";
import SummaryCard from "../components/SummaryCard";
import ActionButton from "../components/ActionButton";

export default function AdminDashboard() {
  return (
    <View style={{ flex: 1, backgroundColor: "#F8F9FA" }}>
      <Header title="Admin Dashboard" subtitle="School Management" />
      <ScrollView style={{ flex: 1, padding: 20 }}>
        <SummaryCard title="Students" count={850} color="#A7C7E7" />
        <SummaryCard title="Teachers" count={45} color="#F9C89B" />
        <SummaryCard title="Classes" count={30} color="#B7E4C7" />
        <SummaryCard title="Users" count={1280} color="#D7BCE8" />

        <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
          <ActionButton label="Manage Students" color="#A7C7E7" />
          <ActionButton label="Manage Teachers" color="#F9C89B" />
          <ActionButton label="Manage Classes" color="#B7E4C7" />
          <ActionButton label="Fees & Payments" color="#D7BCE8" />
        </View>
      </ScrollView>
    </View>
  );
}
